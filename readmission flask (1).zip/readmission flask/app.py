import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle

app = Flask(__name__)
model = pickle.load(open('model1.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')
@app.route('/y_predict',methods=['POST'])
def y_predict():
    '''
    For rendering results on HTML GUI
    '''
    int_features = [x for x in request.form.values()]
    if(int_features[8]=='no'):
        int_features[8]=0
    if(int_features[9]=="no"):
        int_features[9]=0
    else:
        int_features[9]=1
    if(int_features[10]=="no"):
        int_features[10]=0
    else:
        int_features[10]=1
    if(int_features[11]=="no"):
        int_features[11]=0
    else:
        int_features[11]=1
    int_features=[int(x) for x in int_features] 
    final_features = [np.array(int_features)]
    prediction = model.predict(final_features)
    print(prediction)
    output=prediction[0]
    #output="patient readmitted"
    return render_template('index.html', prediction_text='Prediction {}'.format(output))

if __name__ == "__main__":
    app.run(debug=True)
